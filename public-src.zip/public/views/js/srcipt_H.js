document.getElementById('row1').onclick = function(){
    location.href="./bill-01.html";
};    
